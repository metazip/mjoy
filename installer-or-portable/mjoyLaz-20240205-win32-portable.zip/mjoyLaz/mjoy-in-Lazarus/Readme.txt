
mjoy in Lazarus ist eine Portierung von Delphi nach LazarusIDE

mjoy befindet sich noch im Aufbau,
darum sind einige Funktionalitäten noch nicht verwendbar.
Es ist nur eine Preview - wir bitten um Verständnis.

P.S.   die Wörter von mjoy können im vollen Umfang genutzt werden,
        bis auf loadstring und savestring

die Lizenz ist:   (cc-by-3.0) metazip