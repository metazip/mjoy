
mjoy in Lazarus ist eine Portierung von Delphi nach LazarusIDE

mjoy befindet sich noch im Aufbau,
darum sind einige Funktionalitäten noch nicht verwendbar.
Es ist nur eine Preview - wir bitten um Verständnis.

die Lizenz ist:   (CC BY 3.0) metazip