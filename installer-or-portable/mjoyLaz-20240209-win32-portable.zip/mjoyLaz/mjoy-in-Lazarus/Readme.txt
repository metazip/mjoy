
mjoy in Lazarus ist eine Portierung von Delphi nach LazarusIDE

mjoy befindet sich noch im Aufbau,
der Source-Code wird bald nachgeliefert.
Es ist nur eine Preview - wir bitten um Verständnis.

die Lizenz ist:   (CC BY 3.0) metazip